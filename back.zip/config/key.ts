export const mongoURI :string= "mongodb+srv://meriam:meriam123@cluster0.kgdxl.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"

 